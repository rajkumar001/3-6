/**
 * Created by jehaque on 13-Jun-16.
 */

var blogController = helloApp.controller('blogController', function ($scope) {
    $scope.blogs = [


        {
            title: "The unseen Indira Gandhi",
            author: "DR KP Mathur",
            year:"1993",
            image:"image/i.jpg",
            description:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque sed placerat justo, eget tempus tortor. Mauris sagittis dapibus lacinia. Mauris maximus ante ac arcu varius pulvinar. Cras nisi ante, tempor auctor congue interdum, tristique eget risus. Suspendisse tincidunt purus vitae mi tristique auctor. Aliquam pretium et ligula et feugiat. Vivamus."

        },
        {
            title: "A Call to Mercy: Hearts to Love, Hands to Serve",
            author: "Mother Teresa",
            year:"1993",
            image:"image/m.jpg",
            description:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque sed placerat justo, eget tempus tortor. Mauris sagittis dapibus lacinia. Mauris maximus ante ac arcu varius pulvinar. Cras nisi ante, tempor auctor congue interdum, tristique eget risus. Suspendisse tincidunt purus vitae mi tristique auctor. Aliquam pretium et ligula et feugiat. Vivamus."


        },

        {   title:"The Drowned Detective ",
            author:"Neil Jordan",
            year:"1993",
            image:"image/n.jpg",
            description:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque sed placerat justo, eget tempus tortor. Mauris sagittis dapibus lacinia. Mauris maximus ante ac arcu varius pulvinar. Cras nisi ante, tempor auctor congue interdum, tristique eget risus. Suspendisse tincidunt purus vitae mi tristique auctor. Aliquam pretium et ligula et feugiat. Vivamus."
        },


        {
            title:"Blood on my Hands: Confessions of Staged Encounters",
            author:"Kishalay Bhattacharjee",
            year:"1993",
            image:"image/k.jpg",
            description:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque sed placerat justo, eget tempus tortor. Mauris sagittis dapibus lacinia. Mauris maximus ante ac arcu varius pulvinar. Cras nisi ante, tempor auctor congue interdum, tristique eget risus. Suspendisse tincidunt purus vitae mi tristique auctor. Aliquam pretium et ligula et feugiat. Vivamus."
        }


]


})