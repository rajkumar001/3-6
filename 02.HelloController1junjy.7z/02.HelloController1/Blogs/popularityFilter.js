/**
 * Created by rajkumar mandal on 16-06-2016.
 */

helloApp.filter('popularity', function () {
    var max=0;
    return function (value, total) {
        console.log("in popularity");
        total=parseInt(total);
        if(max<total){
            max=total;
        }
        total=Math.round(((5*total)/max));
        for (var i=0; i<total; i++){
            value.push(i)
        }
        return value;
    }

});


