

/**
 * Created by rajkumar mandal on 16-06-2016.
 */




var helloApp = angular.module('helloApp',[]);
