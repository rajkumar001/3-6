

 var blogController;
 blogController = helloApp.controller('blogController', function ($scope, blogService) {
    $scope.sortorder = '';
   


    $scope.increaseVote = function (blog) {
        blog.count++;
    };
    // $scope.blogs=blogService;
    var callBack = function (data) {
        $scope.blogs=data;
    };

    $scope.blogs=blogService(callBack);

});     
