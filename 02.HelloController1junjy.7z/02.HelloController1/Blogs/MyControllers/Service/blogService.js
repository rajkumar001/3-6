/**
 * Created by rajmanda on 6/16/2016.
 */


helloApp.service("blogService", function ($http) {
    return function (cb) {
        $http ({
            method:'GET',
            url:'data/data.JSON'

        }). then(function (response) {
            cb(response.data);
        },function (response) {
            console.log(response);
        });

    }
});
