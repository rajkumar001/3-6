package pojo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import javax.persistence.*;
import javax.swing.plaf.ActionMapUIResource;

import org.hibernate.stat.internal.CategorizedStatistics;




public class FlimTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
		
		EntityManager em = emf.createEntityManager();
		FilmService service = new FilmService(em);
		
		em.getTransaction().begin();
		Image i1=service.createImage("abc", null,  new Date());
		Image i2=service.createImage("xyz", null, new Date());
		Image i3=service.createImage("cfg", null, new Date());
		List<Image> images=new ArrayList<Image>(); 
		images.add(i1);
		images.add(i2);
		images.add(i3);
		
		Image ii1=service.createImage("abc", null, new Date());
		Image ii2=service.createImage("xyz", null, new Date());
		Image ii3=service.createImage("cfg", null, new Date());
		List<Image> images1=new ArrayList<Image>(); 
		images.add(ii1);
		images.add(ii2);
		images.add(ii3); 
		
		Album a1=service.createAlbum("album1", images, null, new Date());
		Album a2=service.createAlbum("album2", images1, null, new Date());	
		
		Category c1=service.createCategory("horrer", null, new Date());
		Category c2=service.createCategory("romantic", null, new Date());
		List<Category> catagories=new ArrayList<Category>();
		catagories.add(c1);
		catagories.add(c2);
		
		Actor aa1=service.createActor("salman", "khan", "m", a1, null, new Date());
		Actor aa2=service.createActor("shahid", "kapoor", "m", a2, null, new Date());
		Actor aa3=service.createActor("SHAHARUKH", "KHAN", "m", a2, null, new Date());
		List<Actor> actor1=new ArrayList<Actor>();
		actor1.add(aa1);
		actor1.add(aa2);
		
		List<Actor> actor2=new ArrayList<Actor>();
		actor2.add(aa1);
		actor2.add(aa3);
		
		Film f1=service.createFilm("DDLJ", "GHFTGFDUIQWEFGUOQEFHE",(short) 1993, a1, "HINDI", actor1, catagories, (byte)5, null, new Date(),(short) 120);
		Film f2=service.createFilm("mp", "GHFTGFDUIQWEFGUOQEFHE", (short)1994, a2, "HINDI", actor2, catagories,(byte) 3, null, new Date(),(short) 126);
		List<Film> films=new ArrayList<Film>();
		films.add(f1);
		films.add(f2);
		
		service.setFilmOnACtor(1, films);
	service.setFilmOnCatagory(1, films);
		em.getTransaction().commit();
		
		
	
		
		
		em.close();
		emf.close();
	}

}

