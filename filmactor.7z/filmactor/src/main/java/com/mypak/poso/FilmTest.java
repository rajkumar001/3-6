package com.mypak.poso;

//import java.util.Date;
//import java.util.List;
import javax.persistence.*;
//import javax.persistence.EntityManager;
//import javax.persistence.EntityManagerFactory;
//import javax.persistence.Persistence;





public class FilmTest {

	public static void main(String[] args) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("hello");
		EntityManager em = emfactory.createEntityManager();
		Film f=new Film();
		Actor act=new Actor();
		
		em.getTransaction().begin();
		f.setId(1);
		f.setTitle("x-man");
		f.setDescription(null);
		f.setReleaseYear(null);
		f.setAlbum(null);
		f.setLanguage("english");
		f.setActor(null);
		f.setCategory(null);
		f.setRating((byte)4);
		f.setDeleteDate(null);
		f.setCreateDate(null);
		f.setLength((short)180);
		em.persist(f);
		em.getTransaction().commit();
		
		em.getTransaction().begin();
		act.setId(1);
		act.setFirstName("hugh");
		act.setLastName("jackman");
		act.setGender("male");
		act.setAlbum(null);
		act.setCreateDate(null);
		act.setDeleteDate(null);
		act.setFilm(null);
		em.persist(act);
		em.getTransaction().commit();
		
		
		
		
		em.close();
		emfactory.close();
		
	}
}
