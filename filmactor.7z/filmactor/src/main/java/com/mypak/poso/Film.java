package com.mypak.poso;
import java.util.Date;
import java.util.List;

import javax.persistence.*;


@Entity
public class Film {
	@Id
	 private int id;
	 private String title;
	 private String description;
	 private Date releaseYear;
		@OneToOne
		private Album album;
		
		
	private String language;
	
	@ManyToMany
	private List<Actor> actor;
	
	@ManyToMany
	private List<Category> category;
	
	private byte rating;
	private Date deleteDate;
	private Date createDate;
	
	//setter and getter
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Film() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getReleaseYear() {
		return releaseYear;
	}
	public void setReleaseYear(Date releaseYear) {
		this.releaseYear = releaseYear;
	}
	public Album getAlbum() {
		return album;
	}
	public void setAlbum(Album album) {
		this.album = album;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public List<Actor> getActor() {
		return actor;
	}
	public void setActor(List<Actor> actor) {
		this.actor = actor;
	}
	public List<Category> getCategory() {
		return category;
	}
	public void setCategory(List<Category> category) {
		this.category = category;
	}
	public byte getRating() {
		return rating;
	}
	public void setRating(byte rating) {
		this.rating = rating;
	}
	public Date getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public short getLength() {
		return length;
	}
	public void setLength(short length) {
		this.length = length;
	}
	private short length;

	// constructor 
	
	/*public Film(Date createDate, String description, String language, short length, byte rating, Date releaseYear,
			String title, List<Actor> actor, List<Category> category, Album album) {
		super();
		this.createDate = createDate;
		this.description = description;
		this.language = language;
		this.length = length;
		this.rating = rating;
		this.releaseYear = releaseYear;
		this.title = title;
		this.actor = actor;
		this.category = category;
		this.album = album;
	}*/
	

	
	
}
