package com.mypak.service;

import java.util.List;

import com.mypak.poso.Actor;

public interface IActorService {
	
	 String addActor(Actor a);
	 
	 List<Actor> searchActorByName(String firstName,String lastNmae);
	 
	 String removeActor(String firstName,String lastName);
	 String modifyActor(String firstName,String lastName);
}
