package com.mypak.repo;


import java.util.List;

import com.mypak.poso.Actor;



public interface IActorRepo {
	public Actor save(Actor actor);
	public List<Actor> findActorByName(String name);
	public boolean remove(String name);
	public boolean updateActor(Actor actor);

}
