/**
 * Created by ttandale on 6/9/2016.
 */


function sendRequest(){
    var XHR = getXHR()
    if(XHR){
        XHR.open("GET","d.json",true);
        XHR.onreadystatechange = function(){handleResponse(XHR);}
        XHR.send();
    }
}

function getXHR(){
    return new XMLHttpRequest();
}

function handleResponse(XHR){
    if(XHR.readyState==4){
        //console.log("data received... ",XHR.responseText);
        var table = document.getElementById('table');
        persons = JSON.parse(XHR.responseText);
console.log(persons);

sor();



    }
}
function showinfo(btn)
{
    butt=btn;
    var fname=persons[btn.id].fname;
    var lname=persons[btn.id].lname;
    var city=persons[btn.id].city;
    var age=persons[btn.id].age;

  console.log(fname);
 var first=document.getElementById("fName");

    first.value=fname;

    var last=document.getElementById("lName");

    last.value=lname;
    var city1=document.getElementById("city");

    city1.value=city;
    var age1=document.getElementById("age");

    age1.value=age;
    



}

function save() {
    var first=document.getElementById("fName").value;



    var last=document.getElementById("lName").value;


    var city1=document.getElementById("city").value;


    var age1=document.getElementById("age").value;

    var table = document.getElementById('table');
   console.log(butt.id);
    persons[butt.id].fname=first;
    persons[butt.id].lname=last;
    persons[butt.id].city=city1;
    persons[butt.id].age=age1;
    while(table.rows.length>0)
    {
        table.deleteRow(0);
    }

   // var row =table.insertRow(butt.id);
   // row.id=butt.id;
   // var cell1 = row.insertCell(0);
   // cell1.innerHTML= "<button type='button' onclick='showinfo(this)' id="+butt.id+">"+last+", "+first+"</button><br>";

sor();



}
function sor()
{
    arr=[]
    for(var i=0;i<persons.length;i++){
        arr[i]=persons[i].lname;

    }
    arr.sort();
    for(var i=0;i<persons.length;i++){
        for(var j=0;j<persons.length;j++){
            if(arr[i]==persons[j].lname)
            {
                t=persons[i];
                persons[i]= persons[j];
                persons[j]=t;
            }

        }

    }
    for(var i=0;i<persons.length;i++){

        var row =table.insertRow(i);
        row.id=i;
        var cell1 = row.insertCell(0);
        cell1.innerHTML= "<button type='button ' class='btn btn-link list-color' onclick='showinfo(this)' id="+i+">"+persons[i].lname+", "+persons[i].fname+"</button><br>";
    }
}

