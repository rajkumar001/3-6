/**
 * Created by akuma373 on 6/9/2016.
 */
function sendRequest(){
    var XHR = getXHR()
    if(XHR){
        XHR.open("GET","data/data.json",true);
        XHR.onreadystatechange = function(){handleResponse(XHR);}
        XHR.send();
    }
}

function getXHR(){
    return new XMLHttpRequest();
}

function handleResponse(XHR) {
    if (XHR.readyState == 4) {

        var sideBar = document.getElementById('addData');
        persons = JSON.parse(XHR.responseText);
      
        for (var i = 0; i < persons.length; i++) {

            var table = document.getElementById("addData");
            var row = table.insertRow(i);
            var cell1 = row.insertCell(0);
            cell1.innerHTML = "<button type='button' class='btn btn-default btn-block' onclick='getDetail(this)' id="
                + i + ">" + persons[i].last_name + " " + persons[i].first_name + "</button>";
        }
    }
}


            function getDetail(btn) {
                document.getElementById('first_name').value = persons[btn.id].first_name;

                document.getElementById('last_name').value = persons[btn.id].last_name;

                document.getElementById('city').value = persons[btn.id].city;

                document.getElementById('state').value = persons[btn.id].state;

            }


            function save() {
               
            }

